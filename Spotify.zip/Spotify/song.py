import os


class Song:
    def __innit__(self):
        pass

    def reproducirCancion():
        print("Selecciona la cancion que te gustaría escuchar")
        print("\n 1 - Still With You - BTS\n")
        print("\n 2 - El Garrobero - Aniceto Molina \n")
        print("\n 3 - Slow Dancing in the Dark -Joji\n")
        print("\n 4 - High Hopes - Panic! At The Disco \n")
        print("\n 5 - Gone, Gone, Gone - Phillip Phillips\n")
        print("\n 6 - Bohemian Rhapsody - Queen\n")
        print("\n 7 - Evangelion Opening 1 - Oikawa Neko\n")

        cwd = os.getcwd()

        song = input("Numero: ")
        separation = "\\Spotify\\canciones\\"
        directory = cwd + separation

        os.system(directory + song + ".mp3")
