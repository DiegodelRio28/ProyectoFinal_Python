from prettytable import PrettyTable
from podcast_view import (
    connection,
    getAllPodcasts,
    addNewPodcast,
    BuscarPodcastPorTema,
    borrarPodcast,
)


def startPodcast_app():
    while True:
        print()
        print("TuMusicApp...")
        print()
        print("*" * 24, "MENÚ", "*" * 24)

        tablePodcast = PrettyTable()
        tablePodcast.field_names = ["OPCION", "ACCION"]
        tablePodcast.add_row([1, "OBTENER TODOS LOS PODCASTS"])
        tablePodcast.add_row([2, "AGREGAR UN NUEVO PODCAST"])
        tablePodcast.add_row([3, "BUSCAR LOS PODCASTS VINCULADOS A UN TEMA"])
        tablePodcast.add_row([4, "ELIMINAR UN PODCAST"])
        tablePodcast.add_row([0, "Salir"])
        print(tablePodcast)
        print("*" * 53)

        option = int(input("ELIJA UNA OPCIÓN: "))

        if option == 1:
            getAllPodcasts()
        elif option == 2:
            addNewPodcast()
        elif option == 3:
            BuscarPodcastPorTema()
        elif option == 4:
            borrarPodcast()
        elif option == 0:
            print("GRACIAS POR USAR NUESTRA APP")
            break
        else:
            print("NO CONTAMOS CON ESA OPCIÓN, POR FAVOR ELIJA UNA OPCIÓN VÁLIDA")
