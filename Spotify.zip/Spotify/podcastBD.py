import pymysql

connection = pymysql.connect(
    host="localhost",
    user="root",
    passwd="12345",
    db="musicapp",
    cursorclass=pymysql.cursors.DictCursor,
)


def getPodcast():
    result = {}
    try:
        with connection.cursor() as cursor:
            sql = "SELECT * FROM musicapp.podcast;"
            cursor.execute(sql)
            result = cursor.fetchall()
    finally:
        pass
    return result


def insertPodcast(name, topic):
    try:
        with connection.cursor() as cursor:
            sql = (
                f"INSERT INTO musicapp.podcast(name, topic) VALUES('{name}','{topic}');"
            )
            cursor.execute(sql)
            connection.commit()
    finally:
        pass


def searchPodcastById(idPodcast):
    podcast = {}
    try:
        with connection.cursor() as cursor:
            sql = f"SELECT * FROM musicapp.podcast WHERE id={idPodcast};"
            cursor.execute(sql)
            podcast = cursor.fetchone()
    finally:
        pass
    return podcast


def searchPodcastByTopic(topic):
    podcast = {}
    try:
        with connection.cursor() as cursor:
            sql = f"SELECT * FROM musicapp.podcast WHERE topic='{topic}';"
            cursor.execute(sql)
            podcast = cursor.fetchall()
    finally:
        pass
    return podcast


def deletePodcast(idPodcast):
    try:
        with connection.cursor() as cursor:
            sql = f"DELETE FROM musicapp.podcast WHERE id={idPodcast};"
            cursor.execute(sql)
            connection.commit()
    finally:
        pass
