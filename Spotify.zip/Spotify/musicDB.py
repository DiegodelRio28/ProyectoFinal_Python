import pymysql

connection = pymysql.connect(
    host="localhost",
    user="root",
    passwd="12345",
    db="musicapp",
    cursorclass=pymysql.cursors.DictCursor,
)


def getSong():
    result = {}
    try:
        with connection.cursor() as cursor:
            sql = "SELECT * FROM musicapp.songs;"
            cursor.execute(sql)
            result = cursor.fetchall()
    finally:
        pass
    return result


def inserSong(name, artist, genre):
    try:
        with connection.cursor() as cursor:
            sql = f"INSERT INTO musicapp.songs(name, artist, genre) VALUES('{name}','{artist}','{genre}');"
            cursor.execute(sql)
            connection.commit()
    finally:
        pass


def searchSongById(idSong):
    song = {}
    try:
        with connection.cursor() as cursor:
            sql = f"SELECT * FROM musicapp.songs WHERE id={idSong};"
            cursor.execute(sql)
            song = cursor.fetchone()
    finally:
        pass
    return song


def searchSongByGenre(genre):
    song = {}
    try:
        with connection.cursor() as cursor:
            sql = f"SELECT * FROM musicapp.songs WHERE genre='{genre}';"
            cursor.execute(sql)
            song = cursor.fetchall()
    finally:
        pass
    return song


def deleteSong(idSong):
    try:
        with connection.cursor() as cursor:
            sql = f"DELETE FROM musicapp.songs WHERE id={idSong};"
            cursor.execute(sql)
            connection.commit()
    finally:
        pass


def getSuscripcion():
    result = {}
    try:
        with connection.cursor() as cursor:
            sql = "SELECT * FROM musicapp.users WHERE premium IS NOT NULL;"
            cursor.execute(sql)
            result = cursor.fetchall()
    finally:
        pass
    return result
