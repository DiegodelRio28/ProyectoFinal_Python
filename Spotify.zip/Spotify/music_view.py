from prettytable import PrettyTable
from musicDB import (
    connection,
    getSong,
    inserSong,
    searchSongById,
    searchSongByGenre,
    deleteSong,
    getSuscripcion,
)


def getAllSongs():
    result = getSong()

    table = PrettyTable()
    table.field_names = ["ID", "Nombre de Canción", "Artista", "Género Musical"]

    for song in result:
        table.add_row([song["id"], song["name"], song["artist"], song["genre"]])

    print(table)

    table.clear()

    SalirGetAllSongs = input("Salir: ")


def addNewSong():

    print("Agregar Canción: ")
    name = input("Nombre: ")
    artist = input("Artista: ")
    genre = input("Género musical: ")

    inserSong(name, artist, genre)
    getAllSongs()


def BuscarCancionPorGenero():

    print("Buscar Artista...")
    genre = input("Ingrese el género que desea buscar: ")

    song = searchSongByGenre(genre)

    tableGenero = PrettyTable()
    tableGenero.field_names = ["ID", "Nombre de Canción", "Artista"]
    for x in song:
        tableGenero.add_row([x["id"], x["name"], x["artist"]])

    print(tableGenero)

    tableGenero.clear()

    SalirBuscarCacionesPorGenero = input("Salir: ")


def borrarSong():
    print("Borrar canción... ")
    id = int(input("Escriba el ID de la canción que desea eliminar: "))

    deleteSong(id)
    getAllSongs()


def getSuscritos():
    result = getSuscripcion()

    table = PrettyTable()
    table.field_names = ["ID", "Nombre", "email", "numero de tarjeta"]

    for users in result:
        table.add_row([users["id"], users["name"], users["email"], users["premium"]])

    print(table)

    table.clear()

    SalirgetSuscritos = input("Salir: ")
