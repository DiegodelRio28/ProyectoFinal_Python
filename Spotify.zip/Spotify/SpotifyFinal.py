from UserI_App import startSpotify_app
from podcast import startPocast_app
from prettytable import PrettyTable
