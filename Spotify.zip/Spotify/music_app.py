from prettytable import PrettyTable
from music_view import (
    connection,
    getAllSongs,
    addNewSong,
    BuscarCancionPorGenero,
    borrarSong,
    getSuscritos,
)


def startMuisc_app():
    while True:
        print()
        print("TuMusicApp...")
        print()
        print("*" * 25, "MENÚ", "*" * 25)

        tableMusic = PrettyTable()
        tableMusic.field_names = ["OPCION", "ACCION"]
        tableMusic.add_row([1, "OBTENER USUARIOS PREMIUM"])
        tableMusic.add_row([2, "OBTENER TODAS LAS CANCIONES"])
        tableMusic.add_row([3, "AGREGAR UNA NUEVA CANCIÓN"])
        tableMusic.add_row([4, "BUSCAR LAS CANCIONES VINCULADAS A UN GÉNERO"])
        tableMusic.add_row([5, "ELIMINAR UNA CANCIÓN"])
        tableMusic.add_row([0, "Salir"])
        print(tableMusic)
        print("*" * 56)

        option = int(input("ELIJA UNA OPCIÓN: "))

        if option == 1:
            getSuscritos()
        elif option == 2:
            getAllSongs()
        elif option == 3:
            addNewSong()
        elif option == 4:
            BuscarCancionPorGenero()
        elif option == 5:
            borrarSong()
        elif option == 0:
            print("GRACIAS POR USAR NUESTRA APP")
            break
        else:
            print("NO CONTAMOS CON ESA OPCIÓN, POR FAVOR ELIJA UNA OPCIÓN VÁLIDA")
