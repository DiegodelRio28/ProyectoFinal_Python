# Esta ventana ha sido creada con el único proposito evaluativo, para que pueda ver como profesor
# ambas ventanas: administrador y usuario. Si desea ver cada una por separado se distribuyen de
# la siguiente manera:
# La ventana con nombre "Amdmin_logic" pertenece a la vista únicamente del administrador.
# La ventana con nombre "UserI_App" pertenece a la vista unicamente del usuario.

# Disfrute la experiencia de SPOTIFY BY ESEN y vuelva pronto, nos vemos.

from prettytable import PrettyTable
from admin_logic import spotifyAdmin
from UserI_App import spotifyUser

while True:
    print()
    print("*" * 20, "SPOTIFY BY ESEN", "*" * 0)
    print()
    print("*" * 12, "MENÚ", "*" * 12)
    tableSpotify = PrettyTable()
    tableSpotify.field_names = ["OPCION", "ACCION"]
    tableSpotify.add_row([1, "ABRIR SPOTIFY COMO ADMINISTRADOR"])
    tableSpotify.add_row([2, "ABRIR SPOTIFY COMO USUARIO"])
    tableSpotify.add_row([0, "SALIR"])
    print(tableSpotify)
    print("*" * 30)

    option = int(input("ELIJA UNA OPCIÓN: "))

    if option == 1:
        spotifyAdmin()
    elif option == 2:
        spotifyUser()
    elif option == 0:
        print("GRACIAS POR PREFERIR SPOTIFYESEN VUELVA PRONTO")
        break
    else:
        print("NO CONTAMOS CON ESA OPCIÓN, POR FAVOR ELIJA UNA OPCIÓN VÁLIDA")
