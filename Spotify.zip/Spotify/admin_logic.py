from music_app import startMuisc_app
from podcast_app import startPodcast_app
from prettytable import PrettyTable
from user_app import startUser_app

# Para poder correr esta vista elimine el "#" del final para activar el llamado del método


def spotifyAdmin():
    while True:
        print()
        print("*" * 20, "SPOTIFY BY ESEN", "*" * 0)
        print()
        print("*" * 12, "MENÚ", "*" * 12)
        tableAdmin = PrettyTable()
        tableAdmin.field_names = ["OPCION", "ACCION"]
        tableAdmin.add_row([1, "ABRIR MUSIC_APP"])
        tableAdmin.add_row([2, "ABRIR PODCAST_APP"])
        tableAdmin.add_row([3, "ABRIR USER_APP"])
        tableAdmin.add_row([0, "EXIT"])
        print(tableAdmin)
        print("*" * 30)

        option = int(input("ELIJA UNA OPCIÓN: "))

        if option == 1:
            startMuisc_app()
        elif option == 2:
            startPodcast_app()
        elif option == 3:
            startUser_app()
        elif option == 0:
            print("GRACIAS POR PREFERIR SPOTIFYESEN VUELVA PRONTO")
            break
        else:
            print("NO CONTAMOS CON ESA OPCIÓN, POR FAVOR ELIJA UNA OPCIÓN VÁLIDA")


# spotifyAdmin()
