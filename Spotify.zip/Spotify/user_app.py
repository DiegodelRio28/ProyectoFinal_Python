from prettytable import PrettyTable
from user_view import (
    connection,
    getAllUsers,
    # addNewUser,
    # no esta
    actualizarUser,
    borrarUser,
)


def startUser_app():
    while True:

        print()
        print("TuMusicApp...")
        print()
        print("*" * 24, "MENÚ", "*" * 24)

        tablePodcast = PrettyTable()
        tablePodcast.field_names = ["OPCION", "ACCION"]
        tablePodcast.add_row([1, "OBTENER TODOS LOS USUARIOS"])
        tablePodcast.add_row([2, "ACTUALIZAR LA INFROMACIÓN DE LOS USUARIOS"])
        tablePodcast.add_row([3, "ELIMINAR A UN USUARIO"])
        tablePodcast.add_row([0, "Salir"])
        print(tablePodcast)
        print("*" * 53)

        option = int(input("ELIJA UNA OPCIÓN: "))

        if option == 1:
            getAllUsers()
        elif option == 2:
            actualizarUser()
        elif option == 3:
            borrarUser()
        elif option == 0:
            print("GRACIAS POR USAR NUESTRA APP")
            break
        else:
            print("NO CONTAMOS CON ESA OPCIÓN, POR FAVOR ELIJA UNA OPCIÓN VÁLIDA")
