from prettytable import PrettyTable
from podcastBD import (
    connection,
    getPodcast,
    insertPodcast,
    searchPodcastById,
    searchPodcastByTopic,
    deletePodcast,
)


def getAllPodcasts():
    result = getPodcast()

    table = PrettyTable()
    table.field_names = ["ID", "Nombre del podcast", "Tema"]

    for podcast in result:
        table.add_row([podcast["id"], podcast["name"], podcast["topic"]])

    print(table)

    table.clear()

    SalirGetAllPodcast = input("Salir: ")


def addNewPodcast():

    print("Agregar Podcast: ")
    name = input("Nombre: ")
    topic = input("Tema: ")

    insertPodcast(name, topic)
    getAllPodcasts()


def BuscarPodcastPorTema():

    print("Buscar Tema...")
    Topic = input("Ingrese el tema que desea buscar: ")

    podcast = searchPodcastByTopic(Topic)

    tableTema = PrettyTable()
    tableTema.field_names = ["ID", "Nombre del podcast", "Tema"]

    for x in podcast:
        tableTema.add_row([x["id"], x["name"], x["topic"]])

    print(tableTema)

    tableTema.clear()

    SalirBuscarCacionesPorGenero = input("Salir: ")


def borrarPodcast():
    print("Borrar podcast... ")
    id = int(input("Escriba el ID del podcast que desea eliminar: "))

    deletePodcast(id)
    getAllPodcasts()
