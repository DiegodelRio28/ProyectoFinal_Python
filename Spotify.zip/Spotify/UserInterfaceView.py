from prettytable import PrettyTable
from UserInterfaceDB import (
    connection,
    addSuscripcion,
    insertSongInPlaylist,
    deleteSub,
    getPlaylist,
    addPlaylist,
    myInfo,
)


def nuevaSuscripcion():
    print(
        "La suscripcion tiene un costo de $5.99, ingrese su tarjeta de credito para continuar"
    )
    print("por favor llene la siguiente informacion:")
    id = input("id de usuario:   ")
    nombre = input("nombre:    ")
    email = input("email:    ")
    tarjetaCredito = input("Tarjeta:   ")
    addSuscripcion(id, nombre, email, tarjetaCredito)
    print("Su cuenta ahora es premium")

    salirNuevaSuscripcion = input("Salir(presione 0): ")


def addSongToPlaylist():
    print("Qué canción va a agregar a qué playlist?:   ")
    playlist = input("Nombre de la playlist:   ")
    song = input("Nombre de la canción:    ")

    insertSongInPlaylist(playlist, song)
    print("La canción ha sido agregada exitosamente")
    salirNuevaSuscripcion = input("Salir(presione 0): ")


def borrarSub():
    print("Eliminar suscripción...")
    Nombre = input("Cuál es su nombre?:    ")

    deleteSub(Nombre)

    print("Se ha borrado su suscripcion exitosamente")
    salirNuevaSuscripcion = input("Salir(presione 0): ")


def verPlaylist():
    result = getPlaylist()

    table = PrettyTable()
    table.field_names = ["ID", "Playlist", "Canciones"]

    for user in result:
        table.add_row([user["id"], user["name"], user["cancion_nombre"]])

    print(table)

    table.clear()

    salirNuevaSuscripcion = input("Salir(presione 0): ")


def nuevaPlaylist():
    print("creando playlist...")
    name = input("Nombre:    ")

    addPlaylist(name)

    print("La playlist ha sido creada exitosamente")

    salirNuevaSuscripcion = input("Salir(presione 0): ")


def verInfo():
    name = input("Ingresa tu nombre para buscar la información:   ")
    result = myInfo(name)

    table = PrettyTable()
    table.field_names = ["ID", "Nombre", "email", " Tarjeta Premium"]

    for nombre in result:
        table.add_row(
            [nombre["id"], nombre["name"], nombre["email"], nombre["premium"]]
        )

    print(table)

    table.clear()

    salirNuevaSuscripcion = input("Salir(presione 0): ")
