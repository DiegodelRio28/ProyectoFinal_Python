import pymysql

connection = pymysql.connect(
    host="localhost",
    user="root",
    passwd="12345",
    db="musicapp",
    cursorclass=pymysql.cursors.DictCursor,
)


def addSuscripcion(id, nombre, email, tarjeta):
    try:
        with connection.cursor() as cursor:
            sql = f"INSERT INTO musicapp.users(id, name, email, premium) VALUES('{id}','{nombre}', '{email}','{tarjeta}');"
            cursor.execute(sql)
            connection.commit()
    finally:
        pass


def insertSongInPlaylist(playlist, song):
    try:
        with connection.cursor() as cursor:
            sql = f"INSERT INTO musicapp.playlist(name, cancion_nombre) VALUES('{playlist}','{song}');"
            cursor.execute(sql)
            connection.commit()
    finally:
        pass


def deleteSub(Nombre):
    try:
        with connection.cursor() as cursor:
            sql = f"DELETE FROM musicapp.users WHERE name='{Nombre}';"
            cursor.execute(sql)
            connection.commit()
    finally:
        pass


def getPlaylist():
    result = {}
    try:
        with connection.cursor() as cursor:
            sql = "SELECT * FROM musicapp.playlist;"
            cursor.execute(sql)
            result = cursor.fetchall()
    finally:
        pass
    return result


def addPlaylist(name):
    try:
        with connection.cursor() as cursor:
            sql = f"INSERT INTO musicapp.playlist(name) VALUES('{name}');"
            cursor.execute(sql)
            connection.commit()
    finally:
        pass


def myInfo(nombre):
    result = {}
    try:
        with connection.cursor() as cursor:
            sql = f"SELECT * FROM musicapp.users WHERE name='{nombre}';"
            cursor.execute(sql)
            result = cursor.fetchall()
    finally:
        pass
    return result