import os


class Podcast:
    def __innit__(self):
        pass

    def reproducirPodcast():
        print("Selecciona el podcast que te gustaría escuchar")
        print("\n 1 - Introducción - Sin Discreciones. Sofia Mora y Rousy Mendoza\n")
        print(
            "\n 2 - Las cosas pasan para tí - Sin Discreciones. Sofia Mora y Rousy Mendoza \n"
        )

        cwd = os.getcwd()

        podcast = input("Numero: ")
        separation = "\\Spotify\\podcast\\"
        directory = cwd + separation

        os.system(directory + podcast + ".mp3")
