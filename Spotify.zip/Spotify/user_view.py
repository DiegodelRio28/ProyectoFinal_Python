from prettytable import PrettyTable
from userDB import (
    connection,
    getUser,
    # insertUser,
    # no existe ese
    searchUserById,
    updateUser,
    deleteUser,
)


def getAllUsers():
    result = getUser()

    table = PrettyTable()
    table.field_names = ["ID", "Nombre de Usuario", "Correo", "Password"]

    for user in result:
        table.add_row([user["id"], user["name"], user["email"], user["password"]])

    print(table)

    table.clear()

    SalirGetAllUser = input("Salir: ")


def actualizarUser():

    print("Actualizar Usuario: ")
    id = int(input("Ingrese el ID del Usuario que desea modificar: "))

    user = searchUserById(id)

    print(user)
    print()

    update = int(
        input("Elija 1 para cambiar de nombre o 0 para pasar al siguiente campo: ")
    )
    if update == 1:
        print(f"Nombre anterior: {user['name']}")
        name = input("Nuevo nombre: ")
    else:
        name = user["name"]

    update = int(input("Elija 1 para cambiar de correo o 0 para terminar: "))
    if update == 1:
        print(f"Correo anterior: {user['email']}")
        email = input("Nuevo correo: ")
    else:
        email = user["email"]

    update = int(input("Elija 1 para cambiar de contraseña o 0 para terminar: "))
    if update == 1:
        print(f"Contraseña anterior: {user['password']}")
        password = input("Nueva contraseña: ")
    else:
        password = user["password"]

    updateUser(id, name, email, password)
    getAllUsers()


def borrarUser():
    print("Borrar Usuario: ")
    id = int(input("Escriba el ID del Usuario que desea eliminar: "))

    deleteUser(id)
    getAllUsers()
