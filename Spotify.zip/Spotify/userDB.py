import pymysql

connection = pymysql.connect(
    host="localhost",
    user="root",
    passwd="12345",
    db="musicapp",
    cursorclass=pymysql.cursors.DictCursor,
)


def getUser():
    result = {}
    try:
        with connection.cursor() as cursor:
            sql = "SELECT * FROM musicapp.users;"
            cursor.execute(sql)
            result = cursor.fetchall()
    finally:
        pass
    return result


def searchUserById(idUser):
    user = {}
    try:
        with connection.cursor() as cursor:
            sql = f"SELECT * FROM musicapp.users WHERE id={idUser};"
            cursor.execute(sql)
            user = cursor.fetchone()
    finally:
        pass
    return user


def updateUser(idUser, name, email, password):
    try:
        with connection.cursor() as cursor:
            sql = f"UPDATE musicapp.users SET name = '{name}', email = '{email}', password = '{password}' WHERE id = {idUser};"
            cursor.execute(sql)
            connection.commit()
    finally:
        pass


def deleteUser(idUser):
    try:
        with connection.cursor() as cursor:
            sql = f"DELETE FROM musicapp.users WHERE id={idUser};"
            cursor.execute(sql)
            connection.commit()
    finally:
        pass
