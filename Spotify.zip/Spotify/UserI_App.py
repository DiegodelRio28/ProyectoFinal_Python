from prettytable import PrettyTable
from song import Song
from podcast import Podcast
from UserInterfaceView import (
    connection,
    nuevaSuscripcion,
    addSongToPlaylist,
    borrarSub,
    verPlaylist,
    nuevaPlaylist,
    verInfo,
)

# Para poder correr esta vista elimine el "#" del final para activar el llamado del método


def spotifyUser():
    while True:
        print()
        print("*" * 20, "SPOTIFY BY ESEN", "*" * 0)
        print("-" * 20, "INICIO", "-" * 20)

        tableUser = PrettyTable()
        tableUser.field_names = ["OPCION", "ACCION"]
        tableUser.add_row([1, "OBTENER UNA SUSCRIPCION"])
        tableUser.add_row([2, "CREAR UNA PLAYLIST"])
        tableUser.add_row([3, "AGREGAR UNA CANCION A LA PLAYLIST"])
        tableUser.add_row([4, "VER TU PLAYLIST"])
        tableUser.add_row([5, "SI TIENE SUSCRIPCION Y DESEA BORRARLA"])
        tableUser.add_row([6, "REPRODUCIR UNA CANCIÓN"])
        tableUser.add_row([7, "REPRODUCIR UNA PODCAST"])
        tableUser.add_row([8, "VER MI INFORMACION"])
        tableUser.add_row([0, "SALIR"])
        print(tableUser)
        print("*" * 56)

        option = int(input("ELIJA UNA OPCION:   "))

        if option == 1:
            nuevaSuscripcion()
        elif option == 2:
            nuevaPlaylist()
        elif option == 3:
            addSongToPlaylist()
        elif option == 4:
            verPlaylist()
        elif option == 5:
            borrarSub()
        elif option == 6:
            Song.reproducirCancion()
        elif option == 7:
            Podcast.reproducirPodcast()
        elif option == 8:
            verInfo()

        elif option == 0:
            print("GRACIAS POR PREFERIR SPOTIFYESEN VUELVA PRONTO")
            break
        else:
            print("NO CONTAMOS CON ESA OPCIÓN, POR FAVOR ELIJA UNA OPCIÓN VÁLIDA")


# spotifyUser()
